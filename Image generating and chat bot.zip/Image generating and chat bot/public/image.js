// public/image.js
const generateBtn = document.getElementById("generateBtn");
const clearHistoryBtn = document.getElementById("clearHistoryBtn");
const promptEl = document.getElementById("prompt");
const resultEl = document.getElementById("result");
const openImages = document.getElementById("openImages");

generateBtn.addEventListener("click", async () => {
  const prompt = promptEl.value.trim();
  if (!prompt) {
    alert("Please enter a prompt.");
    return;
  }
  generateBtn.disabled = true;
  generateBtn.textContent = "Generating...";

  try {
    const res = await fetch("/generate", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ prompt })
    });
    const data = await res.json();
    if (data?.downloadUrl) {
      resultEl.innerHTML = `
        <div>
          <img src="${data.downloadUrl}" alt="Generated image">
        </div>
        <div>
          <a class="download-link" href="${data.downloadUrl}" download="generated.png">⬇ Download</a>
        </div>
      `;
      openImages.href = data.downloadUrl; // quick open latest image
    } else {
      resultEl.textContent = "Failed to generate image.";
    }
  } catch (e) {
    console.error(e);
    resultEl.textContent = "Error generating image.";
  } finally {
    generateBtn.disabled = false;
    generateBtn.textContent = "✨ Generate";
  }
});

clearHistoryBtn.addEventListener("click", async () => {
  if (!confirm("This will delete all generated image files and clear hidden history. Continue?")) return;
  try {
    await fetch("/history", { method: "DELETE" });
    resultEl.innerHTML = `<div style="color:var(--muted)">History cleared.</div>`;
  } catch (e) {
    console.error(e);
    alert("Failed to clear history.");
  }
});
